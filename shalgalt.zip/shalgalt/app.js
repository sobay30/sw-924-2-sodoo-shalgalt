// 1. Өгөгдсөн нэг хэмжээст  бүхэл тоон массивт өгөгдсөн тоо байвал тухай тооны харгалзах индэх-ийг буцаан үгүй бол энэ тоо олдсонгүй  гэж хэвлэ. 
// оролт: [1, 2, 3, 4, 5]; 2
// гаралт: 1


// let arr = [1, 2, 3, 4, 5];
// let too = 2;
// function arg(array, num) {
//     for (let i = 0; i < array.length; i++) {
//       if (array[i] === num) {
//         return "too " + num ;
//       }
//     }
//     return "too" + num + "bish" ;
//   }
// console.log(arg(arr, too));

// 2. Өгөгдсөн тоо хүртэлх натурал тоонуудын факториалыг жишээн дээрх форматаар хэвлэ.
// оролт: 4
// гаралт:
// 1!=1
// 2!=2
// 3!=6
// 4!=24


// function arg(num) {
//     for (let i = 1; i <= num; i++) {
//       let arr = 1;
//       for (let a = 1; a <= i; a++) {
//         arr *= a;
//       }
//       console.log(i + "!=" + arr);
//     }
//   }
//   let too = 4;
//   arg(too);

// 3. 1!+2!+3!+...+n! нийлбэрийг ол.
// оролт: 5
// гаралт: 153


// var y=5;
// var x=1;
// var a=0;
// for(var i=1; i<=y; i++){
// x*=i;
// a+=x;
// }
// console.log(a)

// 4.  азтай тоо гэдэг нь бичлэгтээ зөвхөн 4 болон 7 цифр агуулдаг тоо юм. Жишээ нь 47, 744, 4 тоонууд нь азтай тоо бол 5, 17, 467 тоонууд азтай тоо биш юм.
// тайлбар: "бараг азтай тоо" гэж ямар нэг азтай тоонд үлдэгдэлгүй хуваагддаг тоог нэрлэн. Тэгвэл өгөгдсөн тоо "бараг азтай тоо" эсэхийг шалга.
// оролт: 47
// гаралт:азтай тоо


// function aztoo(num) {
//     let numS = num.toString();
//     for (let i = 0; i < numS.length; i++) {
//     if (numS[i] !== '4' && numS[i] !== '7') {
//     return "азгүй тоо";
//     }
//     }
//     return "азтай тоо";
//     }
    
//     let num = 47;
//     console.log(aztoo(num));

// 5. өгөдсөн тоонд хэдэн тэг орсоныг косолд хэвэл 
// оролт:1007
// гаралт:2


// function too(num) {
//     let a = 0;
//     while(num > 0) {
//       if (num % 10 === 0) {
//         a++;
//       }
//       num = Math.floor(num / 10);
//     }
//     return a;
//   }
//   console.log(too(1007));

// 6. Өгөгдсөн бүхэл тоон массиваас өгөгдсөн дугаарт байх тоог хасаад, хассаны дараах массивт өгөгдсөн дугаарт өгөдсөн тоог нэмж оруул. 
// тайлбар: Массиваас тоо хасна гэдэг нь өгөгдсөн дугаараас хойшхи дугаартай бүх тоонууд урагш нэг шилжихийг хэлнэ. Үүний үр дүнд массивын элементийн тоо 1-ээр цөөрнө. Нэмнэ гэдэг нь өгөгдсөн дугаар болон түүнээс хойшхи дугаартай тоонууд хойш нэг ухарна. Суларсан байранд нь шинэ утга олгогдоно. 
// оролт:[10, 20, 30, 40, 50, 60, 70, 80, 90], 5,7,1000;
// гаралт:[10, 20, 30, 40, 60, 70, 1000, 80, 90]


// let arr = [10, 20, 30, 40, 50, 60, 70, 80, 90];
// let num = 5;
// let index = arr.indexOf(num);
// if (index !== -1) {
//     arr.splice(index, 1);
// }
// num = 7;
// index = arr.indexOf(num);
// if (index !== -1) {
//     arr.splice(index, 1);
// }
// console.log(arr)
// arr.push(1000);
// console.log(arr); 

// 7. Өгөгдсөн натурал тооны цифрүүдийн байрыг солиж гарсан  хамгийн их тоог хэвэл.
// оролт:1928374,
// гаралт:9874321,



// function too(num) {
//     let numS = num.toString();
//     let arr = numS.split("").sort((s, a) => a- s);
    
//     return parseInt(arr.join(""));
//   }
  
//   console.log(too(1928374));

// 8. Хоёр массивыг нэгтгэх, бүх давхардсан элементүүдийг арилгахын тулд JavaScript функц бичнэ үү.
// гаралт = [3, 2, 30, 1];


// function arg(arr1, arr2) {
//     return [...new Set([...arr1, ...arr2])];
//   }
  
//   const arr1 = [3, 2, 30];
//   const arr2 = [2, 1];
//   const too = arg(arr1, arr2);
//   console.log(too);

// 9. 2 ширхэг массив өгөгдсөн бол эхний массиваас зөвхөн сондгой, 2 дахь массиваас зөвхөн тэгш утгуудыг агуулсан шинэ массив үүсгэж буцаа


// function arr(arr1, arr2) {
//     let a = [];
//     for (let i = 0; i < arr1.length; i++) {
//       if (arr1[i] % 2 !== 0) a.push(arr1[i]);
//     }
//     for (let i = 0; i < arr2.length; i++) {
//       if (arr2[i] % 2 === 0) a.push(arr2[i]);
//     }
//     return a;
//   }
  
//   let arr1 = [1, 3, 5, 7, 9];
//   let arr2 = [2, 4, 6, 8, 10];
  
//   console.log(arr(arr1, arr2));

//   let arr = [7, 7];
// let first = arr[0];
// let size = arr.length;
// let sum = first * size;
// console.log(sum);
// 10. маасивийн эхний элемэнт болон уртын хэмжээ өгөдсөн бол эхний элемэтийг уртын хэжээгээр үржүүлж үлдсэн элемэнтүүдийг тооцож гарга
// оролт: 7, 7


// let too = 7;
// function arr(too, length) {
//     let result = [];
//     for (let i = 0; i < length; i++) {
//       result.push(too ** i);
//     }
//     return result;
//   }
  
//   console.log(arr(7, 7));

// 11. passport validator


// let pass = document.querySelector('.pass');
// let a = /[a-z]/g;
// let s = /[A-Z]/g;
// let d = /[0-9]/g;
// let f = /[@$!%*?&]/g;

// let btn= document.querySelector('.btn');
// btn.addEventListener('click', ()=>{
//     if(!pass.value.match(s)){
//         alert("tom useg")
//     } else if(!pass.value.match(a)){
//         alert("useg")
//     }else if(!pass.value.match(d)){
//         alert("too")
//     }else if(!pass.value.match(f)){
//         alert("temdegt")
//     }else{
//         alert("amjilttai")
//     }
// })
// 12. picture model 


// const body = document.querySelector("body");
// async function print(){
//     try {
//           let respopnse = await fetch('http://jsonplaceholder.typicode.com/albums/1/photos');
//     let file =  await respopnse.json();
//     file.forEach((element) => {
//         let img = document.createElement('img');
//         img.src=element.url;
//         body.appendChild(img);
//     });
    
//     console.log(file)
//     } catch (error) {
//         console.log(error);
//     }
// }
// print();

